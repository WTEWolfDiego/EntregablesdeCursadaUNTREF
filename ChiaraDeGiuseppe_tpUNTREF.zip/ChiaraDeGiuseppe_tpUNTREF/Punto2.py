# Punto 2

# Escribir una función que dado el ingreso de 3 variables (a, b, c) retorne las raíces
# resultantes de una ecuación cuadrática.
import math

def ecuacion_cuadratica(a, b, c):
    try:
        discriminante = b**2 - 4*a*c

        if discriminante > 0:
            x1 = int(-b+math.sqrt(b**2-4*a*c)/2*a)
            x2 = int(-b-math.sqrt(b**2-4*a*c)/2*a)
            return f"Dos soluciones reales: x1 = {x1}, x2 = {x2}"
        elif discriminante == 0:
             x = -b / (2 * a)
             return f"Una única solución real: x = {x}"
        else:
            return "No hay soluciones reales (el discriminante es negativo)."
    except ZeroDivisionError:
        return "Error: el valor de 'a' no puede ser 0 (no es una ecuación cuadrática)."

print("Ingrese un valor por cada variable: a, b, c")
a = float(input("Ingrese el valor para a: "))
b = float(input("Ingrese el valor para b: "))
c = float(input("Ingrese el valor para c: "))

resultado = ecuacion_cuadratica(a, b, c)

print(resultado)




