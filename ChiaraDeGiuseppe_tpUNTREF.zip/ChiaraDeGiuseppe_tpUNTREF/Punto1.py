# Punto 1

#Escribir un programa que dado el ingreso de un número retorne si el mismo es primo o no.

def es_primo(num):
    if num <= 1:
        print("El numero no es primo")
    else:
        es_primo = True
        for i in range(2, num):
            if num % i == 0:
                es_primo = False
                break
        if es_primo: 
            print("El numero es primo")
        else:
            print("El numero no es primo")

try:
    num = int(input("Ingrese un número para definir si es primo: "))
    es_primo(num)
except ValueError:
    print("Error: Debe ingresar un número entero válido.")


