import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from pages.finish_page import FinishPage


def test_case_3(driver):
    login_page = LoginPage(driver)
    inventory_page = InventoryPage(driver)
    cart_page = CartPage(driver)
    checkout_page = CheckoutPage(driver)
    finish_page = FinishPage(driver)

    # Login
    login_page.login("standard_user", "secret_sauce")

    # Agregar un producto al carrito
    inventory_page.add_first_item_to_cart()

    # Ir al carrito
    inventory_page.go_to_cart()

    # Remover el artículo
    cart_page.remove_item()

    # Verificar que el carrito esté vacío
    assert cart_page.is_cart_empty()

    # Volver a continuar comprando
    cart_page.continue_shopping()

    # Agregar dos productos
    inventory_page.add_multiple_items_to_cart(2)

    # Ir nuevamente al carrito
    inventory_page.go_to_cart()

    # Verificar que haya 2 elementos
    assert cart_page.get_cart_items_count() == 2

    # Hacer checkout
    cart_page.go_to_checkout()
    checkout_page.input_fields_checkout("Chiara", "De Giuseppe", "1414")

    # Finalizar compra
    finish_page.go_to_finish()

    # Verificar compra finalizada
    assert finish_page.verify_success_message()