import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage

def test_case_1(driver):
    login_page = LoginPage(driver)
    inventory_page = InventoryPage(driver)

    # Login
    login_page.login("standard_user", "secret_sauce")

    # Ordenar por precio
    inventory_page.sort_by_price_low_to_high()

    # Verificar orden
    prices = inventory_page.get_prices()
    assert prices == sorted(prices), "Los precios no están ordenados de menor a mayor"