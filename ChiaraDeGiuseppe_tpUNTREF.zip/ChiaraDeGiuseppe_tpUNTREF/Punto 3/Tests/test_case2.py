import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from pages.finish_page import FinishPage


def test_case_2(driver):
    login_page = LoginPage(driver)
    inventory_page = InventoryPage(driver)
    cart_page = CartPage(driver)
    checkout_page = CheckoutPage(driver)
    finish_page = FinishPage(driver)

    # Login
    login_page.login("standard_user", "secret_sauce")

    #Agregar todo al carrito
    inventory_page.add_all_to_cart()

    #Ir al carrito
    inventory_page.go_to_cart()

    #Ir al checkout
    cart_page.go_to_checkout()


    # Completar solo nombre
    checkout_page.input_fields_checkout(firstname="Chiara")
    error1 = checkout_page.get_error_message()
    assert error1 == "Error: Last Name is required", f"Mensaje inesperado: {error1}"

    # Completar apellido
    checkout_page.input_fields_checkout(firstname="Chiara", lastname="De Giuseppe")
    error2 = checkout_page.get_error_message()
    assert error2 == "Error: Postal Code is required", f"Mensaje inesperado: {error2}"

    # Completar código postal
    checkout_page.input_fields_checkout(firstname="Chiara", lastname="De Giuseppe", zipcode="1414")



    