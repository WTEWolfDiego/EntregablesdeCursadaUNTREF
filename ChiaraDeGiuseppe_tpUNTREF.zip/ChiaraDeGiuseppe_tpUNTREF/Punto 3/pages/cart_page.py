from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class CartPage:
    checkout_button = (By.ID, "checkout")
    cart_items = (By.CLASS_NAME, "cart_item")
    remove_buttons = (By.CLASS_NAME, "cart_button")
    continue_shopping_button = (By.ID, "continue-shopping")

    def __init__(self, driver):
        self.driver = driver

    def go_to_checkout(self):
        self.driver.find_element(*self.checkout_button).click()
    
    def continue_shopping(self):
        self.driver.find_element(*self.continue_shopping_button).click()

    def get_cart_items_count(self):
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_all_elements_located(self.cart_items)
        )
        items = self.driver.find_elements(*self.cart_items)
        return len(items)
    
    def remove_item(self):
        remove_buttons = self.driver.find_elements(*self.remove_buttons)
        if remove_buttons:
            remove_buttons[0].click()

    def is_cart_empty(self):
        items = self.driver.find_elements(*self.cart_items)
        return len(items) == 0

    def get_cart_items_count(self):
        items = self.driver.find_elements(*self.cart_items)
        return len(items)