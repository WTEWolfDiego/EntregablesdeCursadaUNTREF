from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class CheckoutPage:

    def __init__(self, driver):
        self.driver = driver
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)  

        self.first_name_input = (By.ID, "first-name")
        self.last_name_input = (By.ID, "last-name")
        self.zip_code_input = (By.ID, "postal-code")
        self.continue_button = (By.ID, "continue")
        self.error_message = (By.CSS_SELECTOR, "h3[data-test='error']") 

    def input_fields_checkout(self, firstname=None, lastname=None, zipcode=None):
        if firstname is not None:
            field = self.driver.find_element(*self.first_name_input)
            field.clear()
            field.send_keys(firstname)
        if lastname is not None:
            field = self.driver.find_element(*self.last_name_input)
            field.clear()
            field.send_keys(lastname)
        if zipcode is not None:
            field = self.driver.find_element(*self.zip_code_input)
            field.clear()
            field.send_keys(zipcode)

        self.driver.find_element(*self.continue_button).click()


    def get_error_message(self):
        self.wait.until(EC.visibility_of_element_located(self.error_message))
        return self.driver.find_element(*self.error_message).text
