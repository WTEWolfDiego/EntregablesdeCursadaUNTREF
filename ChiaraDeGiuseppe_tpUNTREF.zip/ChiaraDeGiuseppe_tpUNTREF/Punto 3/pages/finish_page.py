from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class FinishPage:
    finish_button = (By.CSS_SELECTOR, "button[data-test='finish']")
    success_message = (By.CSS_SELECTOR, "h2[data-test='complete-header']")

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, 10)
        

    def go_to_finish(self):
        wait = WebDriverWait(self.driver, 10)
        finish_btn = wait.until(EC.element_to_be_clickable(self.finish_button))
        finish_btn.click()
    

    def verify_success_message(self):
        msg = WebDriverWait(self.driver, 15).until(
        EC.visibility_of_element_located(self.success_message)
        )
        return msg.is_displayed()


        