from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class InventoryPage:
    sort_dropdown = (By.CLASS_NAME, "product_sort_container")
    item_prices = (By.CLASS_NAME, "inventory_item_price")
    add_to_cart_buttons = (By.CLASS_NAME, "btn_inventory")
    cart_icon = (By.CLASS_NAME, "shopping_cart_link")

    def __init__(self, driver):
        self.driver = driver

    def sort_by_price_low_to_high(self):
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(self.sort_dropdown)
        )
        select = Select(self.driver.find_element(*self.sort_dropdown))
        select.select_by_visible_text("Price (low to high)")
        
    def get_prices(self):
        elements = self.driver.find_elements(*self.item_prices)
        return [float(e.text.replace("$", "")) for e in elements]

    def add_all_to_cart(self):
        WebDriverWait(self.driver, 10).until(
        EC.presence_of_all_elements_located(self.add_to_cart_buttons)
        )
        buttons = self.driver.find_elements(*self.add_to_cart_buttons)
        for b in buttons:
            b.click()
    
    def add_first_item_to_cart(self):
        button = self.driver.find_element(*self.add_to_cart_buttons)
        button.click()

    def add_multiple_items_to_cart(self, n):
        buttons = self.driver.find_elements(*self.add_to_cart_buttons)
        for b in buttons[:n]:
            b.click()
    
    def go_to_cart(self):
        self.driver.find_element(*self.cart_icon).click()
