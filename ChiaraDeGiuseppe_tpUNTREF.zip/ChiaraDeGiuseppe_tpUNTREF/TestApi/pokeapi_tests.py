import requests


BASE_URL = "https://pokeapi.co/api/v2/"

def test_berry_1():
    response = requests.get(f"{BASE_URL}berry/1")
    response.raise_for_status()
    data = response.json()
    
    assert data["size"] == 20
    assert data["soil_dryness"] == 15
    assert data["firmness"]["name"] == "soft"

def test_berry_2():
    # Obtenemos berry 1 y 2 para comparar
    response1 = requests.get(f"{BASE_URL}berry/1")
    response1.raise_for_status()
    data1 = response1.json()
    
    response2 = requests.get(f"{BASE_URL}berry/2")
    response2.raise_for_status()
    data2 = response2.json()
    
    assert data2["firmness"]["name"] == "super-hard"
    assert data2["size"] > data1["size"]
    assert data2["soil_dryness"] == data1["soil_dryness"]

def test_pikachu():
    response = requests.get(f"{BASE_URL}pokemon/pikachu")
    response.raise_for_status()
    data = response.json()
    
    assert 10 < data["base_experience"] < 1000
    types = [t["type"]["name"] for t in data["types"]]
    assert "electric" in types